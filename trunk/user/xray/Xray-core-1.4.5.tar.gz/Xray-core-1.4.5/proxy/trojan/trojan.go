package trojan

const (
	muxCoolAddress = "v1.mux.cool"
)
