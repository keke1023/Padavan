
This directory contains files that might be useful to analyze iperf3 results

iperf3_to_gnuplot.py: converts iperf3 JSON output to format easy to plot in gnuplot

iperf3.gp: sample gnuplot commands to plot throught and retransmits


Other iperf3 related projects that might be of interest:

https://github.com/kaihendry/iperf3chart

