#ifndef HEADER_ZramMeter
#define HEADER_ZramMeter

#include "Meter.h"


extern const MeterClass ZramMeter_class;

#endif
