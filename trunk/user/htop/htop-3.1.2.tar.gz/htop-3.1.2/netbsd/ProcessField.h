#ifndef HEADER_NetBSDProcessField
#define HEADER_NetBSDProcessField
/*
htop - netbsd/ProcessField.h
(C) 2021 htop dev team
Released under the GNU GPLv2+, see the COPYING file
in the source distribution for its full text.
*/


#define PLATFORM_PROCESS_FIELDS  \
   // End of list


#endif /* HEADER_NetBSDProcessField */
