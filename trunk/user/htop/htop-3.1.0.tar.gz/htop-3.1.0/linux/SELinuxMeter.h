#ifndef HEADER_SELinuxMeter
#define HEADER_SELinuxMeter
/*
htop - SELinuxMeter.h
(C) 2020 htop dev team
Released under the GNU GPLv2, see the COPYING file
in the source distribution for its full text.
*/

#include "Meter.h"


extern const MeterClass SELinuxMeter_class;

#endif /* HEADER_SELinuxMeter */
