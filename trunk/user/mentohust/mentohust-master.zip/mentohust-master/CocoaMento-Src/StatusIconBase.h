//
//  StatusIconBase.h
//  HelloCocoa
//
//  Created by 云尔 on 11-3-29.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//
#ifndef STATUS_ICON_BASE
#define STATUS_ICON_BASE


//class StatusIconBase; {
//public:
//    void handleTrigger(long id);
//};

#endif