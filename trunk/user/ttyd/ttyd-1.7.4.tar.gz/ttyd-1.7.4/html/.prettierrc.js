module.exports = {
  ...require('gts/.prettierrc.json'),
  "bracketSpacing": true,
  "tabWidth": 4,
  "printWidth": 120,
}
