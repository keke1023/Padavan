/* Copyright (c) INRIA and Microsoft Corporation. All rights reserved.
   Licensed under the Apache 2.0 License. */

/* This file is automatically included when compiling with -wasm -d force-c */
#define WasmSupport_check_buffer_size(X)
