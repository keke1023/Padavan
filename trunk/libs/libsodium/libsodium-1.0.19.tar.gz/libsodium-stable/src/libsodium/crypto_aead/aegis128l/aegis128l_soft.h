#ifndef aegis128l_soft_H
#define aegis128l_soft_H

#include "implementations.h"

extern struct aegis128l_implementation aegis128l_soft_implementation;

#endif